﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            ListLoad();
            ListShow();

            button4.Visible = false;
            button6.Visible = false;
            button7.Visible = false;
            button8.Visible = false;
            button9.Visible = false;
            label15.Visible = false;
            textBox6.Visible = false;

        }

        CriminalsList list = new CriminalsList(); 

        public void ListLoad()  // at first check if such a file exists/ if it does - load, if not - create new
        {
            if (File.Exists(@"Crim_list.txt") == false) 
            {
                File.Create(@"Crim_list.txt");
            }
            else
            {
                StreamReader sr = new StreamReader(@"C:\Users\38099\Desktop\Crim_list.txt"); //
                string line;
                while ((line = sr.ReadLine()) != null)
                {
                    string[] arr = line.Split(' ');
                    string[] date_arr = arr[8].Split('.');
                    Criminal n = new Criminal(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6], arr[7], date_arr[0], date_arr[1], date_arr[2], arr[9], arr[10]);
                    list.Add(n);
                }

                sr.Close();
            }
            
        }

        public void ListShow()
        {
            if (list.first != null)
            {
                Criminal current = list.first;

                while (current != null)
                {
                    string ln = current.IntoString();
                    string[] array = ln.Split(" ");
                    dataGridView1.Rows.Add(array);
                    current = current.next;
                }

            }

        }

        private void button1_Click(object sender, EventArgs e) //adding criminal
        {
            Criminal n = new Criminal(textBox12.Text, textBox9.Text, textBox1.Text, comboBox1.Text, textBox8.Text, textBox5.Text, textBox3.Text, textBox11.Text, textBox7.Text, textBox13.Text, textBox14.Text, textBox4.Text, textBox2.Text);
            if (list.Exists(n) == false && n.AllSet() == true)
            {
                list.Add(n);

            //update displayed info
            Criminal current = n;

                string ln = current.IntoString();
                string[] array = ln.Split(" ");
                dataGridView1.Rows.Add(array);

            }
            //else - "such criminal is already on the list"

            Clear();
        }


       Criminal temp;

        private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            button4.Visible = true;
            button6.Visible = true;
            button7.Visible = true;

            button1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;

            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.RowCount - 1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                textBox12.Text = row.Cells[0].Value.ToString();
                textBox9.Text = row.Cells[1].Value.ToString();
                textBox1.Text = row.Cells[2].Value.ToString();
                string s = row.Cells[3].Value.ToString();
                if (s == "Ч")
                {
                    comboBox1.SelectedIndex = 0;
                }
                else
                {
                    comboBox1.SelectedIndex = 1;
                }
                textBox8.Text = row.Cells[4].Value.ToString();
                textBox5.Text = row.Cells[5].Value.ToString();
                textBox3.Text = row.Cells[6].Value.ToString();
                textBox11.Text = row.Cells[7].Value.ToString();
                string date = row.Cells[8].Value.ToString();
                string[] arr = date.Split(".");
                textBox7.Text = arr[0];
                textBox13.Text = arr[1];
                textBox14.Text = arr[2];
                textBox4.Text = row.Cells[9].Value.ToString();
                textBox2.Text = row.Cells[10].Value.ToString();

                Criminal n = new Criminal(textBox12.Text, textBox9.Text, textBox1.Text, comboBox1.Text, textBox8.Text, textBox5.Text, textBox3.Text, textBox11.Text, textBox7.Text, textBox13.Text, textBox14.Text, textBox4.Text, textBox2.Text);

                temp = list.SearchFull(n);
                
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            button4.Visible = false;
            button6.Visible = false;
            button7.Visible = false;

            button1.Visible = true;
            button2.Visible = true;
            button3.Visible = true;

            Clear();

            //textBox1.Text = null;
            //textBox2.Text = null;
            //textBox3.Text = null;
            //textBox4.Text = null;
            //textBox5.Text = null;
            //textBox7.Text = null;
            //textBox8.Text = null;
            //textBox9.Text = null;
            //textBox11.Text = null;
            //textBox12.Text = null;
            //textBox13.Text = null;
            //textBox14.Text = null;
            //comboBox1.SelectedIndex = -1;
        }

        public void Clear()
        {
            textBox1.Text = null;
            textBox2.Text = null;
            textBox3.Text = null;
            textBox4.Text = null;
            textBox5.Text = null;
            textBox7.Text = null;
            textBox8.Text = null;
            textBox9.Text = null;
            textBox11.Text = null;
            textBox12.Text = null;
            textBox13.Text = null;
            textBox14.Text = null;
            comboBox1.SelectedIndex = -1;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Criminal n = new Criminal(textBox12.Text, textBox9.Text, textBox1.Text, comboBox1.Text, textBox8.Text, textBox5.Text, textBox3.Text, textBox11.Text, textBox7.Text, textBox13.Text, textBox14.Text, textBox4.Text, textBox2.Text);
            if (list.Exists(n) == false && n.AllSet() == true)
                list.ChangeCriminal(temp, textBox12.Text, textBox9.Text, textBox1.Text, comboBox1.Text, textBox8.Text, textBox5.Text, textBox3.Text, textBox11.Text, textBox7.Text, textBox13.Text, textBox14.Text, textBox4.Text, textBox2.Text);
            //list.DeleteCriminal(temp);
            //list.AddCriminal(textBox12.Text, textBox9.Text, textBox1.Text, comboBox1.Text, textBox8.Text, textBox5.Text, textBox3.Text, textBox11.Text, textBox7.Text, textBox13.Text, textBox14.Text, textBox4.Text, textBox2.Text);
            
            //clear and refresh datagridview
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            ListShow();
        }


        CriminalsList nList = new CriminalsList();
        private void button2_Click(object sender, EventArgs e)
        {
            button8.Visible = true;
            button9.Visible = true;
            button4.Visible = false;
            button6.Visible = false;
            button1.Visible = false;
            label15.Visible = true;
            textBox6.Visible = true;

            nList = list.Search(textBox12.Text, textBox9.Text, textBox1.Text, comboBox1.Text, textBox8.Text, textBox5.Text, textBox3.Text, textBox11.Text, textBox7.Text, textBox13.Text, textBox14.Text, textBox4.Text, textBox2.Text);
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            if (nList.first != null)
            {
                Criminal current = nList.first;

                while (current != null)
                {
                    string ln = current.IntoString();
                    string[] array = ln.Split(" ");
                    dataGridView1.Rows.Add(array);
                    current = current.next;
                }

            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            button8.Visible = false;
            button9.Visible = false;
            button1.Visible = true;
            button4.Visible = false;
            button6.Visible = false;
            label15.Visible = false;
            textBox6.Visible = false;

            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            ListShow();

            Clear();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f = new Form2();
            f.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            File.WriteAllText(@"C:\Users\38099\Desktop\Crim_list.txt", string.Empty); //

            StreamWriter f = new StreamWriter(@"C:\Users\38099\Desktop\Crim_list.txt"); //

            if (list.first != null)
            {
                Criminal current = list.first;
                while (current != null)
                {
                    string line = current.IntoString();
                    f.WriteLine(line);

                    current = current.next;
                }
            }

            f.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Criminal n = new Criminal(textBox12.Text, textBox9.Text, textBox1.Text, comboBox1.Text, textBox8.Text, textBox5.Text, textBox3.Text, textBox11.Text, textBox7.Text, textBox13.Text, textBox14.Text, textBox4.Text, textBox2.Text);
            n = list.SearchFull(n);

            if (File.Exists(@"Archive.txt") == false)
            {
                File.Create(@"Archive.txt");
            }
            else
            {
                StreamWriter f = new StreamWriter(@"C:\Users\38099\Desktop\Archive.txt", true); //
                string line = n.IntoString();
                f.WriteLine(line);
                f.Close();

                list.DeleteCriminal(n);
                dataGridView1.Rows.Clear();
                dataGridView1.Refresh();
                ListShow();

                File.WriteAllText(@"C:\Users\38099\Desktop\Crim_list.txt", string.Empty); //

                StreamWriter f2 = new StreamWriter(@"C:\Users\38099\Desktop\Crim_list.txt"); //

                if (list.first != null)
                {
                    Criminal current = list.first;
                    while (current != null)
                    {
                        string li = current.IntoString();
                        f2.WriteLine(li);

                        current = current.next;
                    }
                }

                f2.Close();
            }

           

            Clear();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            string path = "";
            if (textBox6.Text == "")
            {
                path = @"D:\SearchResults.txt";
            }
            else
            {
                path = @"D:\" + textBox6.Text + ".txt";
            }

            nList.Save(path);
            textBox6.Text = null;
        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
