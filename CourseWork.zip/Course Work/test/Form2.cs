﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace test
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();

            button1.Visible = false;
            button3.Visible = false;

            button9.Visible = false;
            label15.Visible = false;
            textBox6.Visible = false;

            ListLoad();
            ListShow();
        }

        CriminalsList list = new CriminalsList();

        public void ListLoad()  // at first check if such a file exists/ if it does - load, if not - create new
        {
            if (File.Exists(@"Archive.txt") == false)
            {
                File.Create(@"Archive.txt");
            }
            StreamReader sr = new StreamReader(@"C:\Users\38099\Desktop\Archive.txt"); //
            string line;
            while ((line = sr.ReadLine()) != null)
            {
                string[] arr = line.Split(' ');
                string[] date_arr = arr[8].Split('.');
                Criminal n = new Criminal(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6], arr[7], date_arr[0], date_arr[1], date_arr[2], arr[9], arr[10]);
                list.Add(n);
            }

            sr.Close();
        }

        public void ListShow()
        {
            if (list.first != null)
            {
                Criminal current = list.first;

                while (current != null)
                {
                    string ln = current.IntoString();
                    string[] array = ln.Split(" ");
                    dataGridView1.Rows.Add(array);
                    current = current.next;
                }

            }

        }


        private void button2_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            list.DeleteCriminal(temp);
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            ListShow();

            File.WriteAllText(@"C:\Users\38099\Desktop\Archive.txt", string.Empty);

            StreamWriter f = new StreamWriter(@"C:\Users\38099\Desktop\Archive.txt");

            if (list.first != null)
            {
                Criminal current = list.first;
                while (current != null)
                {
                    string line = current.IntoString();
                    f.WriteLine(line);

                    current = current.next;
                }
            }

            f.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            list.DeleteCriminal(temp);
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            ListShow();

            File.WriteAllText(@"C:\Users\38099\Desktop\Archive.txt", string.Empty);

            StreamWriter f = new StreamWriter(@"C:\Users\38099\Desktop\Archive.txt");

            if (list.first != null)
            {
                Criminal current = list.first;
                while (current != null)
                {
                    string ln = current.IntoString();
                    f.WriteLine(ln);

                    current = current.next;
                }
            }

            f.Close();

            StreamWriter file = new StreamWriter(@"C:\Users\38099\Desktop\Crim_list.txt", true);
            string line = temp.IntoString();
            file.WriteLine(line);
            file.Close();

            Form1 form = new Form1();
            string[] array = line.Split(" ");
            form.dataGridView1.Rows.Add(array);

            //form.dataGridView1.Rows.Clear();
            //form.dataGridView1.Refresh();
            //foreach (var ln in File.ReadLines(@"C:\Users\38099\Desktop\Crim_list.txt"))
            //{
            //    string[] array = ln.Split(" ");
            //    form.dataGridView1.Rows.Add(array);
            //}
        }

        Criminal temp;
        private void dataGridView1_RowHeaderMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            button1.Visible = true;
            button3.Visible = true;

            if (e.RowIndex >= 0 && e.RowIndex < dataGridView1.RowCount - 1)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                string date = row.Cells[8].Value.ToString();
                string[] arr = date.Split(".");
                Criminal n = new Criminal(row.Cells[0].Value.ToString(), row.Cells[1].Value.ToString(), row.Cells[2].Value.ToString(), row.Cells[3].Value.ToString(),
                                          row.Cells[4].Value.ToString(), row.Cells[5].Value.ToString(), row.Cells[6].Value.ToString(), row.Cells[7].Value.ToString(), arr[0], arr[1],
                                          arr[2], row.Cells[9].Value.ToString(), row.Cells[10].Value.ToString());
                temp = n;
            }
                
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button9.Visible = true;
            label15.Visible = true;
            textBox6.Visible = true;

            CriminalsList nList = new CriminalsList();
            nList = list.Search(textBox12.Text, textBox9.Text, textBox1.Text, comboBox1.Text, textBox8.Text, textBox5.Text, textBox3.Text, textBox11.Text, textBox7.Text, textBox13.Text, textBox14.Text, textBox4.Text, textBox2.Text);
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            if (nList.first != null)
            {
                Criminal current = nList.first;

                while (current != null)
                {
                    string ln = current.IntoString();
                    string[] array = ln.Split(" ");
                    dataGridView1.Rows.Add(array);
                    current = current.next;
                }

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button9.Visible = false;
            label15.Visible = false;
            textBox6.Visible = false;

            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
            ListShow();

            Clear();
        }
        public void Clear()
        {
            textBox1.Text = null;
            textBox2.Text = null;
            textBox3.Text = null;
            textBox4.Text = null;
            textBox5.Text = null;
            textBox7.Text = null;
            textBox8.Text = null;
            textBox9.Text = null;
            textBox11.Text = null;
            textBox12.Text = null;
            textBox13.Text = null;
            textBox14.Text = null;
            comboBox1.SelectedIndex = -1;
        }

        CriminalsList nList = new CriminalsList();
        private void button9_Click(object sender, EventArgs e)
        {
            string path = "";
            if (textBox6.Text == "")
            {
                path = @"D:\SearchResults.txt";
            }
            else
            {
                path = @"D:\" + textBox6.Text + ".txt";
            }

            nList.Save(path);
            textBox6.Text = null;
        }
    }
}
