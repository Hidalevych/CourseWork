﻿using System;

public class Criminal
{
	public Criminal next;

	// характеристики злочинця
	string name;
	string surname;
	string nickname;
	string height;
	string hair_color;
	string eye_color;
	string nationality;
	string sex;
	string birth_day;
	string birth_month;
	string birth_year;
	string profession;
	string special;


	public string Name
    {
		get { return name; }
		set { name = value; }
    }
	public string Surname
    {
		get { return surname; }
		set { surname = value; }
	}
	public string Nickname
    {
		get { return nickname; }
		set 
		{ 
			if (value == "") 
			{ 
				nickname = "-"; 
			} 
			else
            {
				nickname = value;
			}			
		}
	}
	public string Height
    {
		get { return height; }
		set
		{
			if (value == "")
			{
				height = "-";
			}
            else
            {
				int h = 0;
				try
				{
					h = Convert.ToInt32(value);
					if (h > 0)
					{
						string h_ = Convert.ToString(h);
						height = h_;
					}
					else
					{
						height = "-";
					}
				}
				catch
				{
					height = "-";
				}
			}
			
		}
	}
	public string Hair_color
    {
		get { return hair_color; }
		set 
		{
			if (value == "")
			{
				hair_color = "-";
			}
			else
            {
				hair_color = value;
			}
		}
	}
	public string Eye_color
    {
		get { return eye_color; }
		set
		{
			if (value == "")
			{
				eye_color = "-";
			}
			else
			{
				eye_color = value;
			}
		}
	}
	public string Nationality
    {
		get { return nationality; }
		set { nationality = value; }
	}
	public string Sex
    {
		get { return sex; }
		set { sex = value; }
	}
	public string Birth_day
    {
		get { return birth_day; }
        set
        {
			int day = 0;
			try
            {
				day = Convert.ToInt32(value);
				if (day > 0 && day < 32)
                {
					birth_day = value;
                }
				else
                {
					birth_day = "00";
                }
            }
            catch
            {
				birth_day = "00";
            }
        }
    }
	public string Birth_month
    {
		get { return birth_month; }
		set
		{
			int month = 0;
			try
			{
				month = Convert.ToInt32(value);
				if (month > 0 && month < 13)
				{
					birth_month = value;
				}
				else
				{
					birth_month = "00";
				}
			}
			catch
			{
				birth_month = "00";
			}
		}
	}
	public string Birth_year
    {
		get { return birth_year; }
		set
		{
			int year = 0;
			try
			{
				year = Convert.ToInt32(value);
				if (year > 0 && year < 2007)
				{
					birth_year = value;
				}
				else
				{
					birth_year = "0000";
				}
			}
			catch
			{
				birth_year = "0000";
			}
		}
	}
	public string Profession
    {
		get { return profession; }
		set
		{
			if (value == "")
			{
				profession = "-";
			}
			else
			{
				profession = value;
			}
		}
	}
	public string Special
    {
		get { return special; }
		set
		{
			if (value == "")
			{
				special = "-";
			}
			else
			{
				special = value;
			}
		}
	}


	public Criminal() { }
	public Criminal(string name_,
		string nick,
		string sur,
		string sx,
		string height_, 
		string hair,
		string eye,
		string nation,
		string b_day,  
		string b_month,   
		string b_year,  
		string prof,
		string spec)
	{
		Name = name_;
		Surname = sur;
		Nickname = nick;
		Height = height_;
		Hair_color = hair;
		Eye_color = eye;
		Nationality = nation;
		Sex = sx;
		Birth_day = b_day;
		Birth_month = b_month;
		Birth_year = b_year;
		Profession = prof;
		Special = spec;
	}


	// перевірка внесення обов'язкових даних
	public bool AllSet()
    {
		if (Name != "" && Surname != "" && Nationality != "" && Sex != "")
        {
			return true;
        }
		return false;
    }

	// переведення характеристик у текстовий рядок
	public string IntoString()
    {
		string s = $"{this.Name} {this.Nickname} {this.Surname} {this.Sex} {this.Height} {this.Hair_color} {this.Eye_color} " +
			       $"{this.Nationality} {this.Birth_day}.{this.Birth_month}.{this.Birth_year} {this.Profession} {this.Special}"; 
		return s;
    }

	// порівняння злочинців
	public bool Equals(Criminal n)
    {
		if (this.Name == n.Name && this.Surname == n.Surname && this.Nickname == n.Nickname && this.Birth_day == n.Birth_day && this.Sex == n.Sex && this.Height == n.Height &&
			this.Birth_month == n.Birth_month && this.Birth_year == n.Birth_year && this.Eye_color == n.Eye_color && this.Special == n.Special && this.Hair_color == n.Hair_color && this.Profession == n.Profession && this.Nationality == n.Nationality)
		{
			return true;
		}
		return false;
	}

	// копіювання злочинця
	public Criminal Copy(Criminal crim)
    {
		Criminal n = new Criminal(crim.Name, crim.Nickname, crim.Surname, crim.Sex, crim.Height, crim.Hair_color, crim.Eye_color, crim.Nationality, crim.Birth_day, crim.Birth_month, crim.Birth_year, crim.Profession, crim.Special);
		return n;
    }

	
}
