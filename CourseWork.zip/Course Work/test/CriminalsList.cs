﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace test
{
    public class CriminalsList
    {
        public Criminal first;

        public CriminalsList() { }

        /*
        public void AddCriminal(    
		   string name_,
		   string nick,
		   string sur,
		   string sx,
		   string height_,
		   string hair,
		   string eye,
		   string nation,
		   string b_day,
		   string b_month,
		   string b_year,
		   string prof,
		   string spec)
        {
			Criminal n = new Criminal(
				name_,
				nick,
				sur,
				sx,
				height_,
				hair,
				eye,
				nation,
				b_day,
				b_month,
				b_year,
				prof,
				spec);

			if (first == null)
            {
				first = n;
				//return true;
			}
			else
            {
				Criminal current = first;
				while (current.next != null)
				{
					current = current.next;
				}
				current.next = n;
				//return true;
			}			
        }
		*/

        // додавання злочинця до списку
        public void Add(Criminal n)   
		{
			if (first == null)
            {
				first = n;
			}
            else
            {
				Criminal current = first;
				while (current.next != null)
                {
					current = current.next;
                }
				current.next = n;
            }
        }

		// перевірка чи існує такий елемент списку
		public bool Exists(Criminal n)
        {
			if (first == null)
            {
				return false;
            }

			Criminal current = first;
			while(current != null)
            {
				if (current.Equals(n) == true)
                {
					return true;
                }
				current = current.next;
            }
			return false;
        }

		// пошук конкретного злочинця
		public Criminal SearchFull(Criminal n)
        {
			Criminal current = first;
			while (current != null)
			{
				if (current.Equals(n))
				{
					return current;
				}
				current = current.next;
			}
			return first;
		}

		// метод для зміни існуючого елементу списку
		public void ChangeCriminal(
		   Criminal toChange,
		   string name_,
		   string nick,
		   string sur,
		   string sx,
		   string height_,
		   string hair,
		   string eye,
		   string nation,
		   string b_day,
		   string b_month,
		   string b_year,
		   string prof,
		   string spec)
        {
			toChange.Name = name_;
			toChange.Nickname = nick;
			toChange.Surname = sur;
			toChange.Sex = sx;
			toChange.Height = height_;
			toChange.Hair_color = hair;
			toChange.Eye_color = eye;
			toChange.Nationality = nation;
			toChange.Birth_day = b_day;
			toChange.Birth_month = b_month;
			toChange.Birth_year = b_year;
			toChange.Profession = prof;
			toChange.Special = spec;
        }

		// видалення зі списку
		public void DeleteCriminal(Criminal toDelete)
        {
			if (first == null)
            {
				return;
            }
			if (Exists(toDelete) == false)
            {
				return;
            }
			if (first.Equals(toDelete) == true)
            {
				first = first.next;
				return;
            }
			Criminal current = first;
			while (current.next.Equals(toDelete) != true)
            {
				current = current.next;
            }
			current.next = current.next.next;
        }

		// пошук за вказаними характеристиками
		public CriminalsList Search(
		   string name_,
		   string nick,
		   string sur,
		   string sx,
		   string height_,
		   string hair,
		   string eye,
		   string nation,
		   string b_day,
		   string b_month,
		   string b_year,
		   string prof,
		   string spec)
        {
			CriminalsList nList = new CriminalsList();
			string line = $"{name_} {nick} {sur} {sx} {height_} {hair} {eye} {nation} {b_day}.{b_month}.{b_year} {prof} {spec}";
			string[] arr = line.Split(" ");
			int count = 0;
			for (int i = 0; i < arr.Length; i += 1)
            {
				if (arr[i] != "" && arr[i] != "..")
                {
					count += 1;
                }
            }

			Criminal current = this.first;
			int j = 0;
			while (current != null)
            {
				string c_line = current.IntoString();
				string[] crim = c_line.Split(" ");
				for (int i = 0; i < arr.Length; i += 1)
                {
					if (arr[i] != "" && arr[i] != "..")
                    {
						if (arr[i] == crim[i])
                        {
							j += 1;
                        }
                        else
                        {
							break;
						}
						
                    }
                }
				if (j == count)
                {
					Criminal n = new Criminal();
					n = n.Copy(current);
					nList.Add(n);
                }
				current = current.next;
				j = 0;
            }

			return nList;
		}

		// збереження списку в файл
		public void Save(string path)
        {
			FileStream fileStream = null;
			if (File.Exists(path) == false)
            {
				fileStream = File.Create(path); 
			}
            else
            {
				File.Delete(path);
				fileStream = File.Create(path);
			}

			StreamWriter output = new StreamWriter(fileStream);

			if (first != null)
			{
				Criminal current = first;
				while (current != null)
				{
					string li = current.IntoString();
					output.WriteLine(li);

					current = current.next;
				}
			}

			output.Close();
		}

		// завантаження списку з файлу
		public void Load(string path)
        {
			if (File.Exists(path))
			{
				StreamReader sr = new StreamReader(path); 
				string line;
				while ((line = sr.ReadLine()) != null)
				{
					string[] arr = line.Split(' ');
					string[] date_arr = arr[8].Split('.');
					Criminal n = new Criminal(arr[0], arr[1], arr[2], arr[3], arr[4], arr[5], arr[6], arr[7], date_arr[0], date_arr[1], date_arr[2], arr[9], arr[10]);
					this.Add(n);
				}

				sr.Close();
			}
		}
    }
}
